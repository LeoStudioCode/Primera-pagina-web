<?php
session_start();
$varsesion=$_SESSION['correo'];
if($varsesion == null || $varsesion = ""){
    echo 'usted no se ha autentificado';
    die(); //terminar la aplicacion para que no continue ejecutandose
}
?>
<?php
include 'conexion.php';
// CONSULTA A NUESTROS RESGISTROS DADOS DE ALTA
$consulta="select * from comentarios";
$resultado=mysqli_query($conexion,$consulta);
$nfilas=mysqli_num_rows($resultado);

//INSERTAR REGISTROS
if(isset($_REQUEST['cve_comentario']) && !isset($_REQUEST['clave'])){
    $cve_comentario=$_REQUEST['cve_comentario'];
    $nombre=$_REQUEST['nombre'];
    $apellidos=$_REQUEST['apellidos'];
    $correo=$_REQUEST['correo'];
    $telefono=$_REQUEST['telefono'];
    $comentario=$_REQUEST['comentario'];

    $subio=false;
    $subio=true;
    if($subio){
        $insertar="INSERT INTO `comentarios`(`cve_comentario`, `nombre`, `apellidos`, `correo`, `telefono`, `cometnario`) VALUES ('$cve_comentario','$nombre','$apellidos','$correo','$telefono','$cometnario')";
        mysqli_query($conexion,$insertar);
        echo "<script>alert('Administrador Registrado');</script>";
        echo"<script>window.location='cat_admin.php';</script>";
            
    }


else{
    echo"<script>alert('Error');</script>";
}
}
//ELIMINAR REGISTROS
if(isset($_REQUEST['eliminar'])){
    $eliminar=$_REQUEST['eliminar'];
    mysqli_query($conexion,"delete from comentarios where cve_comentario=$eliminar");
    echo "<script>alert('Comentario Eliminado');</script>";
    echo"<script>window.location='comentarios.php';</script>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Catalogo Usuarios</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
        <section class="menu_cat">
            <h6>Administrador: <?php echo $_SESSION['nombre'];?></h6>
            <a href="../html/menu_admin.php"> <button class="active">regresar</button></a>
        </section>
    <section id="contenedor">
            <h2 class="registrado">Comentarios de los Clietnes</h2><br>
         <div class="catalogos-comentarios">
            <table class="catt">
            <tr class="tabla-nombre">
                <td>Nombre</td>
                <td>Apellidos</td>
                <td>Correo</td>
                <td>Telefono</td>
                <td>Mensaje</td>
                <td>Hora del Mensaje</td>
                <td>Eliminar</td>
            </tr>
                <?php while($comentarios=mysqli_fetch_array($resultado)) {?>
                <tr class="tabla-info">
                    <td><?php echo $comentarios['nombre']?></td>
                    <td><?php echo $comentarios['apellidos']?></td>
                    <td><?php echo $comentarios['correo'] ?></td>
                    <td><?php echo $comentarios['telefono'] ?></td>
                    <td><?php echo $comentarios['comentario']?></td>
                    <td><?php echo $comentarios['timestamp']?></td>
                    <td><a class="fas fa-trash-alt fa-2x" href="comentarios.php?eliminar=<?php echo $comentarios['cve_comentario']; ?>"></a></td>
                </tr> 
                <?php }?>
            </table>
         </div>
    </section>
</body>
</html>