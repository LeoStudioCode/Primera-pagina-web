<!-- 
    //INGRESAR CON ROLES
    include_once 'database.php';

    session_start();

    if(isset($_GET['cerrar_sesion'])){
        
        session_unset();

        session_destroy();
    }

    if(isset($_SESSION['rol'])){

        switch($_SESSION['rol']){
            case 1:
                 //Coloco la localizacion de ese rol
                header('location: menu_admin.php');
            break;
    
            case 2:
            header('location: prueba2.php');
            break;
    
            default:
        }
    }
    if(isset($_POST['correo']) && isset($_POST['password'])){
        $correo = $_POST['correo'];
        $password = $_POST['password'];

        $db = new Database();
        $query = $db->connect()->prepare('SELECT*FROM usuario WHERE correo = :correo AND password = :password');
        $query->execute(['correo' => $correo, 'password' => $password]);
        $row = $query->fetch(PDO::FETCH_NUM);
        if($row == true){
            // validar rol (si el usuario agregado tiene el rol que le especificaste te va a mandar a la direccion que le dices con el header)
            $rol = $row[8];
            $_SESSION['rol'] = $rol;
            
            switch($_SESSION['rol']){
                case 1:
                     //Coloco la localizacion de ese rol
                    header('location: menu_admin.php');
                break;
        
                case 2:
                header('location: prueba2.php');
                break;
        
                default:
            }
        }else{
            
            
            <h5 class="error">El usuario o contraseña son incorrectos</h5>
            ?php
        // no existe el usuario
    }

}
//QUE TAL PERSONA CON DIFERENTE ROL PUEDA INCIAR EN ESA PAGINA
session_start();
//$varsesion=$_SESSION['correo'];
if(!isset($_SESSION['rol'])){
    header('location: login.php');
}else{
    if($_SESSION['rol'] != 1){
        header('location: login.php');
    }
}
-->
<?php

include 'conexion.php';

$cat_categoria="SELECT * FROM categoria";
$resutado = mysqli_query($conexion, $cat_categoria);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
    <header>
                <nav>
                    <ul class="menu">
                    <h1 class="icon-restaurant">Restaurante del Tio</h1>
                    <li><a href="../html/index.php" class="icon-menu">Inicio</a></li>
                    <li><a class="icon-restaurant" href="../html/productos.php">Productos</a>
                    <ul class="menu-vertical">
                        <?php while ($categoria=mysqli_fetch_array($resutado)) {?>
                            <li> <a href="prod_general.php?id_categoria=<?php echo $categoria['id_categoria']; ?>"><?php echo $categoria['nombre']; ?></a></li>
                            <?php } ?> 
                    </ul>
                    <li><a href="../html/conocenos.php" class="icon-blogger">Conocenos</a></li>
                    <li><a href="../html/contactanos.php" class="icon-users">Contactanos</a></li>
                    <li><a href="../html/login.php" class="icon-login">Inicie sesion</a></li>
                    </ul>     
                </nav>
    </header>

    <section id="login">
        <div class="login-box">
            <h5>Inicia Aqui</h5><br>
        
            <form action = "../html/validar_login.php" method = "POST" class= "BOX" >
                <!--username-->
                <label for="correo">Correo</label>
                <input type="text" placeholder="Introduce usuario" name = "correo" class="controls">
        
                <!---password-->
                <label for="password">Contraseña</label>
                <input type="password" placeholder="Intruduce Contraseña" name = "password" maxlength="8" class="controls">
        
        
                <!---------boton de login--->
                <input type="submit" value="Iniciar Sesión">
                <!------------------------------------->
                
                <b><a href="#">Olvidaste tu cuenta?</a></b><br>
                <b><a href="#">Olvidaste tu contraseña?</a></b>
               
            </form>
           </div>
    </section>

    <footer>
        <div class="footer">
        <h4>Restaurante del tio &copy;</h4>
            <div class="redes">
                <a class="icon-twitter-bird" href="#"></a>
                <a class="icon-instagram-filled" href="#"></a>
                <a class="icon-whatsapp" href="#"></a>
                <a class="icon-facebook-rect" href="#"></a>
            </div>
        </div>
    </footer>
</body>
</html>