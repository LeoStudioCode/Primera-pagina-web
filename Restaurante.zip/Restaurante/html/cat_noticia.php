<?php
session_start();
$varsesion=$_SESSION['correo'];
if($varsesion == null || $varsesion = ""){
    echo 'usted no se ha autentificado';
    die(); //terminar la aplicacion para que no continue ejecutandose
}
?>
<?php
include 'conexion.php';
// CONSULTA A NUESTROS RESGISTROS DADOS DE ALTA
$consulta="select * from noticia";
$resultado=mysqli_query($conexion,$consulta);
$nfilas=mysqli_num_rows($resultado);

//INSERTAR REGISTROS
if(isset($_REQUEST['cve_noticia']) && !isset($_REQUEST['clave'])){
    $cve_noticia=$_REQUEST['cve_noticia'];
    $fecha=$_REQUEST['fecha'];
    $titulo=$_REQUEST['titulo'];
    $contenido=$_REQUEST['contenido'];

    $subio=false;
    $subio=true;
    if($subio){
        $insertar="INSERT INTO `noticia`(`cve_noticia`, `fecha`, `titulo`, `contenido`) VALUES ('$cve_noticia','$fecha','$titulo','$contenido')";
        mysqli_query($conexion,$insertar);
        echo "<script>alert('Noticia Publicada');</script>";
        echo"<script>window.location='cat_noticia.php';</script>";
            
    }
    
   else{
    echo"<script>alert('Error');</script>";
   }
}
//ELIMINAR REGISTROS
if(isset($_REQUEST['eliminar'])){
    $eliminar=$_REQUEST['eliminar'];
    mysqli_query($conexion,"delete from noticia where cve_noticia=$eliminar");
    echo "<script>alert('Noticia Eliminada');</script>";
    echo"<script>window.location='cat_noticia.php';</script>";
}

//EDITAR REGISTROS
//1.Consulta el registro que va editar
if(isset($_REQUEST['editar'])){
    $editar=$_REQUEST['editar'];
    $registros1=mysqli_query($conexion, "select * from noticia where cve_noticia=$editar");
    $reg=mysqli_fetch_array($registros1);
}
//2.Actualiza el Registro
if(isset($_REQUEST['clave'])){
    $cve_noticia=$_REQUEST['clave'];
    $fecha=$_REQUEST['fecha'];
    $titulo=$_REQUEST['titulo'];
    $contenido=$_REQUEST['contenido'];

    $subio=false;
    $subio=true;
    if($subio){
        mysqli_query($conexion, "update noticia set fecha='$fecha', titulo='$titulo', contenido='$contenido' where cve_noticia='$cve_noticia'");
        echo "<script>alert('Noticia Actualizada');</script>";
        echo"<script>window.location='cat_noticia.php';</script>";
            
    }
    


else{
    echo"<script>alert('Error');</script>";
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Catalogo Usuarios</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
        <section class="menu_cat">
            <h6>Administrador: <?php echo $_SESSION['nombre'];?></h6>
            <a href="../html/menu_admin.php"> <button class="active">regresar</button></a>
        </section>
    <section id="contenedor">
        <section id="general">
            
            <form action="cat_noticia.php" method="post" enctype="multipart/form-data">

                <label for="cve_noticia">Clave Noticia</label>
                <input type="text" name="cve_noticia" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['cve_noticia']."' disabled"; } ?>placeholder="Clave" size="10"  class="Decorar_cat" readonly><br>
                <label for="fecha">Fecha: </label>
                <input type="date" name="fecha" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['fecha']."' "; } ?>placeholder="Fecha" size="90" class="Decorar_cat"><br>
                <label for="titulo">Titulo: </label>
                <input type="text" name="titulo" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['titulo']."' "; } ?>placeholder="Titulo" size="25" class="Decorar_cat"><br>
                <textarea name="contenido" placeholder="Noticia" cols="100" rows="10" class="Decorar_cat-textarea"><?php if(isset($_REQUEST['editar'])) {echo $reg['contenido']; } ?></textarea><br>
        
                <?php 
                //creamos y pasamos un campo oculto que contiene la clave del empleado
                if(isset($_REQUEST['editar']))
                { echo "<input type='hidden' name='clave' value='".$reg['cve_noticia']."' >" ;}
                ?>

                <!-- Dependiendo si es insertar o editar el boton cambia su etiqueta -->
                <cosita class="button">
                <input type="submit"<?php if(isset($_REQUEST['editar'])){echo "value='Guardar'";} else {echo "value='Insertar'";} ?> id="boton">
                </cosita>
            </form>
        </section><br>
            <h2 class="registrado">Noticias Registradas</h2><br>
        <div class="catalogos">
            <table class="catt">
            <tr class="tabla-nombre">
                <td>Fecha</td>
                <td>Titulo</td>
                <td>Noticia</td>
                <td>Eliminar</td>
                <td>Editar</td>
            </tr>
                <?php while($noticia=mysqli_fetch_array($resultado)) {?>
                <tr class="tabla-info">
                    <td><?php echo $noticia['fecha']?></td>
                    <td><?php echo $noticia['titulo'] ?></td>
                    <td><?php echo $noticia['contenido']?></td>
                    <td><a class="fas fa-trash-alt fa-2x" href="cat_noticia.php?eliminar=<?php echo $noticia['cve_noticia']; ?>"></a></td>
                    <td><a class="fas fa-edit fa-2x" href="cat_noticia.php?editar=<?php echo $noticia['cve_noticia'];?>"> </a></td>
                </tr>
                <?php }?>
            </table>
        </div>
    </section>
</body>
</html>