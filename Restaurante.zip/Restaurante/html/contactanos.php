<?php

include 'conexion.php';

$cat_categoria="SELECT * FROM categoria";
$resutado = mysqli_query($conexion, $cat_categoria);

// CONSULTA A NUESTROS RESGISTROS DADOS DE ALTA
$consulta="select * from comentarios";
$resultado=mysqli_query($conexion,$consulta);
$nfilas=mysqli_num_rows($resultado);

//INSERTAR REGISTROS
if(isset($_POST['nombre'])){
    $nombre=$_POST['nombre'];
    $apellidos=$_POST['apellidos'];
    $correo=$_POST['correo'];
    $telefono=$_POST['telefono'];
    $comentario=$_POST['comentario'];

    $insertar="insert into comentarios (nombre, apellidos, correo, telefono, comentario) VALUES ('$nombre','$apellidos','$correo','$telefono','$comentario')";
    if (mysqli_query($conexion,$insertar)){  
        echo "<script>alert('Comentario Enviado');</script>";
        echo"<script>window.location='contactanos.php';</script>";
    }
    else{
        echo"<script>alert('Error');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contactanos</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
    <header>
                <nav>
                    <ul class="menu">
                    <h1 class="icon-restaurant">Restaurante del Tio</h1>
                    <li><a href="../html/index.php" class="icon-menu">Inicio</a></li>
                    <li><a class="icon-restaurant" href="../html/productos.php">Productos</a>
                    <ul class="menu-vertical">
                        <?php while ($categoria=mysqli_fetch_array($resutado)) {?>
                            <li> <a href="prod_general.php?id_categoria=<?php echo $categoria['id_categoria']; ?>"><?php echo $categoria['nombre']; ?></a></li>
                            <?php } ?> 
                    </ul>
                    <li><a href="../html/conocenos.php" class="icon-blogger">Conocenos</a></li>
                    <li><a href="../html/contactanos.php" class="icon-users">Contactanos</a></li>
                    <li><a href="../html/login.php" class="icon-login">Inicie sesion</a></li>
                    </ul>     
                </nav>
    </header>

    <section id="contactanos">
        <h2>Ponte en Contacto</h2>
        <div id="box_contacto">
            <form action="contactanos.php" method="POST" class="box-cont-peque">
                
                <div >
                <input type="text" name="nombre" size="40" maxlength="30" placeholder="Nombre completo" class="box-input-cont" requiered>
                <input type="text" name="apellidos" value="" size="40" maxlength="30" placeholder="Apellidos completo" class="box-input-cont">
                </div><br>

                <div >
                <input type="text" name="correo" value="" size="40" maxlength="40" placeholder="Correo Electronico" class="box-input-cont">
                <input type="text" name="telefono" value="" size="40" maxlength="10" placeholder="Telefono completo" class="box-input-cont">
                </div><br>

                <div >
                <textarea name="comentario" cols="20" rows="10" maxlength="414"class="box-texarea-cont" placeholder="Comentario"></textarea><br>
                </div><br>

                <div class="input-enviar">
                <button>Enviar</button>
                </div>
            </form>
        </div>
    </section>

    <footer>
        <div class="footer">
        <h4>Restaurante del tio &copy;</h4>
            <div class="redes">
                <a class="icon-twitter-bird" href="#"></a>
                <a class="icon-instagram-filled" href="#"></a>
                <a class="icon-whatsapp" href="#"></a>
                <a class="icon-facebook-rect" href="#"></a>
            </div>
        </div>
    </footer>
    
</body>
</html>