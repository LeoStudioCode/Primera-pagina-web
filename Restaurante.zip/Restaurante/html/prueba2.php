
<!-- 
   session_start();

    if(!isset($_SESSION['rol'])){
        header('location: login.php');
    }else{
        if($_SESSION['rol'] != 2){
            header('location: login.php');
        }
    }
-->




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <h1>cliente</h1>
    
<nav><ul>
    <li><a class="active" href="cerrar.php">Cerrar Sesión</a></li> </ul>
    <h5 class="active"><a href="cerrar.php">Cerrar Sesión</a></h5>
</nav>
</body>
</html>