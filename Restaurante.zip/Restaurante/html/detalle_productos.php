<?php
session_start();
$varsesion=$_SESSION['correo'];
if($varsesion == null || $varsesion = ""){
    echo 'usted no se ha autentificado';
    die(); //terminar la aplicacion para que no continue ejecutandose
}
?>
<?php
include 'conexion.php';
$cve_producto=$_GET['cve_producto'];

$consulta="select * from productos where cve_producto=$cve_producto";
$resultado=mysqli_query($conexion,$consulta);
$productos=mysqli_fetch_assoc($resultado);

//$consulta=mysqli_query($conexion,"select * from tabla");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Detalle empleado</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
    
    <section class="menu_cat">
        <h6>DETALLE: <?php echo $productos['nombre'];?></h6>
        <a href="../html/cat_prod.php"> <button class="active">regresar</button></a>
    </section>
    <section id="contenedor_detalle">
        <div class="detalle">
        <table class="detalle_tabla">
                
                <tr>
                    <td>Nombre: </td>
                    <td><?php echo $productos['nombre'];?></td>
                </tr>
                    <tr>
                    <td>Descripcion: </td>
                    <td><?php echo $productos['descripcion'];?></td>
                    </tr>
                    <tr>
                    <td>Precio: </td>
                    <td>$<?php echo $productos['precio'];?></td>
                    </tr>
                    <tr>
                        <td>Categoria: </td>
                        <td><?php echo $productos['id_categoria'];?></td>
                    </tr>
                    <tr>
                    <td class="imagen_Detalle"><img src="<?php echo $productos['imagen'];?>"/></td>
                    </tr>
                
        </table>
        </div>   
    </section>
</body>
</html>