<?php
include 'conexion.php';
$cve_producto=$_GET['cve_producto'];

$consulta="select * from productos where cve_producto=$cve_producto";
$resultado=mysqli_query($conexion,$consulta);
$productos=mysqli_fetch_assoc($resultado);

//$consulta=mysqli_query($conexion,"select * from tabla");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Detalle empleado</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
    
    <section class="menu_cat_det">
        <h6>DETALLE: <?php echo $productos['nombre'];?></h6>
        <a href="../html/prod_general.php?id_categoria=<?php echo $productos['id_categoria'];?>"> <button class="active">regresar</button></a>
    </section>
    <section id="contenedor_detalle_pordgen">
        <div class="detalle_prodgen">
        <table class="detalle_tabla_prodgen">
                
                <tr>
                    <td>Nombre: </td>
                    <td><?php echo $productos['nombre'];?></td>
                </tr>
                    <tr>
                    <td>Descripcion: </td>
                    <td><?php echo $productos['descripcion'];?></td>
                    </tr>
                    <tr>
                    <td>Precio: </td>
                    <td>$<?php echo $productos['precio'];?></td>
                    </tr>
                    <tr>
                    <td class="imagen_Detalle"><img src="<?php echo $productos['imagen'];?>"/></td>
                    </tr>
                
        </table>
        </div>   
    </section>
</body>
</html>