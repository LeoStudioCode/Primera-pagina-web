<?php
session_start();
$varsesion=$_SESSION['correo'];
if($varsesion == null || $varsesion = ""){
    echo 'usted no se ha autentificado';
    die(); //terminar la aplicacion para que no continue ejecutandose
}
?>
<?php
include 'conexion.php';
// CONSULTA A NUESTROS RESGISTROS DADOS DE ALTA
$consulta="select * from login";
$resultado=mysqli_query($conexion,$consulta);
$nfilas=mysqli_num_rows($resultado);

//INSERTAR REGISTROS
if(isset($_REQUEST['id_usuario']) && !isset($_REQUEST['clave'])){
    $id_usuario=$_REQUEST['id_usuario'];
    $correo=$_REQUEST['correo'];
    $password=$_REQUEST['password'];
    $nombre=$_REQUEST['nombre'];
    $imagen=$_REQUEST['imagen'];

    $subio=false;
    $directorio='../img_admin';
    $imagen=$directorio."/".$_FILES['imagen']['name'];

    if(is_uploaded_file($_FILES['imagen']['tmp_name'])){
        move_uploaded_file($_FILES['imagen']['tmp_name'],$imagen);
        $subio=true;
        if($subio){
            $insertar="insert into login (id_usuario, correo, password, nombre, imagen) VALUES ('$id_usuario','$correo','$password','$nombre','$imagen')";
            mysqli_query($conexion,$insertar);
            echo "<script>alert('Administrador Registrado');</script>";
            echo"<script>window.location='cat_admin.php';</script>";
            
        }
    }


else{
    echo"<script>alert('Error');</script>";
}
}
//ELIMINAR REGISTROS
if(isset($_REQUEST['eliminar'])){
    $eliminar=$_REQUEST['eliminar'];
    mysqli_query($conexion,"delete from login where id_usuario=$eliminar");
    echo "<script>alert('Administrador Eliminado');</script>";
    echo"<script>window.location='cat_admin.php';</script>";
}

//EDITAR REGISTROS
//1.Consulta el registro que va editar
if(isset($_REQUEST['editar'])){
    $editar=$_REQUEST['editar'];
    $registros1=mysqli_query($conexion, "select * from login where id_usuario=$editar");
    $reg=mysqli_fetch_array($registros1);
}
//2.Actualiza el Registro
if(isset($_REQUEST['clave'])){
    $id_usuario=$_REQUEST['clave'];
    $correo=$_REQUEST['correo'];
    $password=$_REQUEST['password'];
    $nombre=$_REQUEST['nombre'];
    $imagen=$_REQUEST['imagen'];

    if(empty($imagen)){
        $imagen1= $_REQUEST['archivo_mod'];

        mysqli_query($conexion, "update login set correo='$correo', password='$password', nombre='$nombre', imagen='$imagen1' where id_usuario='$id_usuario'");
        echo "<script>alert('Administrador Actualizado');</script>";
        echo"<script>window.location='cat_admin.php';</script>";
    }

    $subio=false;
    $directorio='../img_admin';
    $imagen=$directorio."/".$_FILES['imagen']['name'];

    if(is_uploaded_file($_FILES['imagen']['tmp_name'])){
        move_uploaded_file($_FILES['imagen']['tmp_name'],$imagen);
        $subio=true;
        if($subio){
            mysqli_query($conexion, "update login set correo='$correo', password='$password', nombre='$nombre', imagen='$imagen' where id_usuario='$id_usuario'");
            
        }
    }


else{
    echo"<script>alert('Error');</script>";
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Catalogo Usuarios</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
        <section class="menu_cat">
            <h6>Administrador: <?php echo $_SESSION['nombre'];?></h6>
            <a href="../html/menu_admin.php"> <button class="active">regresar</button></a>
        </section>
    <section id="contenedor">
        <section id="general">
            
            <form action="cat_admin.php" method="post" enctype="multipart/form-data">

                <label for="id_usuario">Clave Admin</label>
                <input type="text" name="id_usuario" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['id_usuario']."' disabled"; } ?>placeholder="Clave" size="10"  class="Decorar_cat" readonly><br>
                <label for="correo">Correo: </label>
                <input type="text" name="correo" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['correo']."' "; } ?>placeholder="Correo" size="90" class="Decorar_cat"><br>
                <label for="password">Contraseña: </label>
                <input type="text" name="password" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['password']."' "; } ?>placeholder="Contraseña" size="100" class="Decorar_cat"><br>
                <label for="nombre">Nombre: </label>
                <input type="text" name="nombre" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['nombre']."' "; } ?>placeholder="Nombre Admin" size="40" class="Decorar_cat"><br>
                <label for="imagen">Fotografia: </label>
                <input type="file" name="imagen" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['imagen']."' ";  ?>placeholder="Fotografia" size="40" class="Decorar_cat"><img src="<?php echo $reg['imagen']; ?>" alt="" width="100" height="100" /> <?php  } ?><br>
        
                <?php 
                //Creamos un campo oculto archivo_mod
                if(isset($_REQUEST['editar']))
                { echo "<input type='hidden' name='archivo_mod' value='".$reg['imagen']."' >" ;}
                //creamos y pasamos un campo oculto que contiene la clave del empleado
                if(isset($_REQUEST['editar']))
                { echo "<input type='hidden' name='clave' value='".$reg['id_usuario']."' >" ;}
                ?>

                <!-- Dependiendo si es insertar o editar el boton cambia su etiqueta -->
                <br><cosita class="button">
                <input type="submit"<?php if(isset($_REQUEST['editar'])){echo "value='Guardar'";} else {echo "value='Insertar'";} ?> id="boton">
                </cosita>
            </form>
        </section><br>
            <h2 class="registrado">Administradores Registrados</h2><br>
        <div class="catalogos">
            <table class="catt">
            <tr class="tabla-nombre">
                <td>Clave Admin</td>
                <td>Nombre</td>
                <td>Foto</td>
                <td>Correo</td>
                <td>Eliminar</td>
                <td>Editar</td>
            </tr>
                <?php while($admin=mysqli_fetch_array($resultado)) {?>
                <tr class="tabla-info">
                    <td><a href="detalle_admin.php?id_usuario=<?php echo $admin['id_usuario'];?>"> <?php echo $admin['id_usuario']?></a></td>
                    <td><?php echo $admin['nombre']?></td>
                    <td><img src="<?php echo $admin['imagen'] ?>" alt=""></td>
                    <td><?php echo $admin['correo']?></td>
                    <td><a class="fas fa-trash-alt fa-2x" href="cat_admin.php?eliminar=<?php echo $admin['id_usuario']; ?>"></a></td>
                    <td><a class="fas fa-edit fa-2x" href="cat_admin.php?editar=<?php echo $admin['id_usuario'];?>"> </a></td>
                </tr>
                <?php }?>
            </table>
        </div>
    </section>
</body>
</html>