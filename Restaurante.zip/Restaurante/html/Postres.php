<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proyecto</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
    <header>
                <nav>
                    <ul class="menu">
                    <h1 class="icon-restaurant">Restaurante del Tio</h1>
                    <li><a href="../html/index.php" class="icon-menu">Inicio</a></li>
                    <li><a href="../html/productos.php">Productos</a>
                        <ul>
                            <li><a href="../html/tacos.php">Tacos</a></li>
                            <li><a href="../html/Postres.php">Postres</a></li>
                            <li><a href="../html/bebidas.php">Bebidas</a>
                        </ul>
                    <li><a href="../html/conocenos.php" class="icon-blogger">Conocenos</a></li>
                    <li><a href="../html/contactanos.php" class="icon-users">Contactanos</a></li>
                    <li><a href="../html/login.php" class="icon-login">Inicie sesion</a></li>
                    </ul>     
                </nav>
    </header>

    <section id="banner">
        <div class="contenedor">
            <img src="../img_prod/Banner2.jpg" alt="banner">
        </div>
    </section>

    <section id="productos">
        
        <div class="contenedor">
            <h2>POSTRES</h2>
            <article>
                <img src="../img_prod/churros.jpg" alt="churros">
                <h3>Churros $10.00</h3>
            </article>
            <article>
                <img src="../img_prod/donas.jpg" alt="donas">
                <h3>Donas $7.00</h3>
            </article>
            <article>
                <img src="../img_prod/pastes chocolate.jfif" alt="pastel">
                <h3>Pastel de chocolate $55.00</h3>
            </article>
            <article>
                <img src="../img_prod/pay.jfif" alt="pay">
                <h3>Pay de manzana $50.00</h3>
            </article>
        </div>
    </section>

    <footer>
            <div class="footer">
            <h4>Restaurante del tio &copy;</h4>
                <div class="redes">
                    <a class="icon-twitter-bird" href="#"></a>
                    <a class="icon-instagram-filled" href="#"></a>
                    <a class="icon-whatsapp" href="https://wa.me/qr/7KBOPQIVIZOOP1"></a>
                    <a class="icon-facebook-rect" href="#"></a>
                </div>
            </div>
    </footer>
</body>
</html>