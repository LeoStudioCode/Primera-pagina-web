<?php
session_start();
$varsesion=$_SESSION['username'];
if($varsesion == null || $varsesion = "")
{
    echo  "<script> alert('Usted no ha ingresado'); </script>";
    die();
}

$_SESSION['nombre']=$_SESSION['nombre'];

include 'conexion.php';

//consulta a los registros de la tabla clientes
$consulta="select *  from clientes";
$resultado=mysqli_query($conexion,$consulta);
$nfilas=mysqli_num_rows($resultado);



//Editar registros
//1.consulta el registro que se va a editar
if(isset($_REQUEST['editar'])){
    $editar=$_REQUEST['editar'];
    $registros1=mysqli_query($conexion, "select * from clientes where cve_cliente=$editar");
    $reg=mysqli_fetch_array($registros1);
}
//consulta para actualizar registros
if(isset($_REQUEST['clave'])){
        $cve_cliente=$_REQUEST['clave'];
        $nombre=$_REQUEST['nombre'];
        $fecha_nacimiento=$_REQUEST['fecha_nacimiento'];
        $telefono=$_REQUEST['telefono'];
        $correo=$_REQUEST['correo'];
        $edad=$_REQUEST['edad'];
        $sexo=$_REQUEST['sexo'];
        $direccion=$_REQUEST['direccion'];
        $estado=$_REQUEST['estado'];
        $servicio=$_REQUEST['servicio'];
        $acudio=$_REQUEST['Acudio'];
        $archivo=$_REQUEST['archivo'];
    
        
    
        if(empty($archivo)){
            $archivo1=$_REQUEST['archivo_mod'];
            mysqli_query($conexion,"update clientes set nombre= '$nombre', fecha_nacimiento= '$fecha_nacimiento', telefono='$telefono',correo='$correo', edad= '$edad', sexo='$sexo', direccion='$direccion',estado='$estado',servicio='$servicio',Acudio='$acudio', archivo='$archivo1' where cve_cliente='$cve_cliente' ");
            
        if(empty($servicio)){
            $servicio1= $_REQUEST['cat_mod'];
    
            mysqli_query($conexion, "update clientes set nombre= '$nombre', fecha_nacimiento= '$fecha_nacimiento', telefono='$telefono',correo='$correo', edad= '$edad', sexo='$sexo', direccion='$direccion',estado='$estado',servicio='$servicio1',Acudio='$acudio', archivo='$archivo1' where cve_cliente='$cve_cliente' ");
        }
            echo "<script>alert('Cliente registrado'); </script>";
            echo "<script>window.location='clientes.php'</script>";
        }
        $subio=false;
        $directorio='archivos';
        $archivo=$directorio."/".$_FILES['archivo']['name'];

        if(is_uploaded_file($_FILES['archivo']['tmp_name']))
        {
            move_uploaded_file($_FILES['archivo']['tmp_name'],$archivo);
            $subio=true;
            if($subio)
            {

                mysqli_query($conexion,"update clientes set nombre= '$nombre', fecha_nacimiento= '$fecha_nacimiento', telefono='$telefono',correo='$correo', edad= '$edad', sexo='$sexo', direccion='$direccion',estado='$estado',servicio='$servicio',Acudio='$acudio', archivo='$archivo' where cve_cliente='$cve_cliente' ");
   
                
                
                
            }
        }
    else
    {
        echo "<script>alert('Error'); </script>";
    }




}


//Insertar registros
if(isset($_REQUEST['cve_cliente'])  && !isset($_REQUEST['clave'])) {
    $cve_cliente=$_REQUEST['cve_cliente'];
    $nombre=$_REQUEST['nombre'];
    $fecha_nacimiento=$_REQUEST['fecha_nacimiento'];
    $telefono=$_REQUEST['telefono'];
    $correo=$_REQUEST['correo'];
    $edad=$_REQUEST['edad'];
    $sexo=$_REQUEST['sexo'];
    $direccion=$_REQUEST['direccion'];
    $estado=$_REQUEST['estado'];
    $servicio=$_REQUEST['servicio'];
    $acudio=$_REQUEST['Acudio'];
    $archivo=$_REQUEST['archivo'];

    $subio=false;
    $directorio='archivo';
    $archivo=$directorio."/".$_FILES['archivo']['name'];

    if(is_uploaded_file($_FILES['archivo']['tmp_name'])){
        move_uploaded_file($_FILES['archivo']['tmp_name'],$archivo);  
        $subio=true;
        if($subio){
            $insertar = "insert into clientes(cve_cliente,nombre,fecha_nacimiento,telefono,correo,edad,sexo,direccion,estado,servicio,Acudio,archivo) VALUES ('$cve_cliente','$nombre','$fecha_nacimiento','$telefono','$correo','$edad','$sexo','$direccion','$estado','$servicio','$acudio','$archivo')";
            mysqli_query($conexion,$insertar);
            echo"<script>alert('Cliente Registrado'); </script>";
            echo"<script>window.location='clientes.php'</script>";
        }

    
    else{
        echo "<script>alert('Error'); </script>";
        }

    }
}

//eliminar
if(isset($_REQUEST['eliminar'])){
    $eliminar=$_REQUEST['eliminar'];
    mysqli_query($conexion,"delete from clientes where cve_cliente=$eliminar");
    echo "<script>alert('Registro Borrado'); </script>";
    echo "<script>window.location='clientes.php'</script>";
}



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laboratorio</title>
    <link rel="stylesheet" href="css/cliente.css">
    <link rel="stylesheet" href="css/lista.css">
    <link rel="icon" href="img/Logo.ico">
</head>
<body>
    <nav>
    <h1>Registro de clientes</h1>
    
    </nav>
   
   
   
    <div class="container-form">
    <form action="clientes.php" method="post" enctype="multipart/form-data">
       
         <input type="text" name="cve_cliente"<?php if(isset($_REQUEST['editar'])) { echo "value='".$reg['cve_cliente']."'";   }?> placeholder="Clave" size="10" maxlength="8" > 

        <input type="text" name="nombre" <?php if(isset($_REQUEST['editar'])) { echo "value='".$reg['nombre']."'";   }?> placeholder="Nombre completo" class="campo">
        <div class="campo">
        <label for="fecha_nacimiento">Fecha_nacimiento </label>
        <input type="tex" name="fecha_nacimiento"<?php if(isset($_REQUEST['editar'])) { echo "value='".$reg['fecha_nacimiento']."'";   }?> >
    </div>
        <input type="text" name="telefono" <?php if(isset($_REQUEST['editar'])) { echo "value='".$reg['telefono']."'";   }?> placeholder="Telefono" class="campo">
        <input type="email" name="correo" <?php if(isset($_REQUEST['editar'])) { echo "value='".$reg['correo']."'";   }?> placeholder="Email" class="campo">
        <input  type="number" name="edad" <?php if(isset($_REQUEST['editar'])) { echo "value='".$reg['edad']."'";   }?> placeholder="Edad" min="1" max="200"  class="campo">
<br>
        <input type="text" name="sexo" <?php if(isset($_REQUEST['editar'])) { echo "value='".$reg['sexo']."'";   }?> placeholder="Sexo" class="campo">
    <input type="text" name="direccion" <?php if(isset($_REQUEST['editar'])) { echo "value='".$reg['direccion']."'";   }?> placeholder="dirección" class="campo">
    <input type="text" name="estado" <?php if(isset($_REQUEST['editar'])) { echo "value='".$reg['estado']."'";   }?> placeholder="Estado" class="campo">
<br>   
         <label for="campo">Servicio</label>
         <select name="servicio" id="servicio" placeholder="Servicio:">
                <option value="<?php echo $reg['servicio']; ?>">Seleccione:</option>
                <?php
                $consulta_dep=mysqli_query($conexion, "select * from servicios");
                while ($depa=mysqli_fetch_array($consulta_dep)) {
                echo '<option value="'.$depa['nombre'].'">'.$depa['nombre'].'</option>'; } ?>
            </select>
     <div class="campo">
        <label for="fecha">Acudio: </label>
        <input type="text" name="Acudio" <?php if(isset($_REQUEST['editar'])) { echo "value='".$reg['Acudio']."'";   }?> min="2022-01-27">
    </div>
    
    <label for="archivo">Fotografia</label>
            <input type="file" name="archivo" <?php if(isset($_REQUEST['editar'])) { echo "value='".$reg['archivo']."'";   ?>placeholder="Fotografia"><img src="<?php echo $reg['archivo']; ?>" alt="" width="100" height="100"/><?php } ?>
<br>
<?php 
                //Creamos un campo oculto archivo_mod
                if(isset($_REQUEST['editar']))
                { echo "<input type='hidden' name='archivo_mod' value='".$reg['archivo']."' >" ;}

                //creamos y pasamos un campo oculto que contiene la clave del empleado
                if(isset($_REQUEST['editar']))
                { echo "<input type='hidden' name='clave' value='".$reg['cve_cliente']."' >" ;}
                
                //Creamos un campo oculto depto_mod
                if(isset($_REQUEST['editar']))
                { echo "<input type='hidden' name='cat_mod' value='".$reg['servicio']."' >" ;}
                ?>
        <br>
        <cosita class="enviar">
        <input type="submit" name="enviar" value="Enviar formulario" class="btn-enviar" >
        </cosita>
        <cosita class="enviar2">
        <a href="cerrar_sesion.php"><input type="button" name="cerrar_sesion" value="cerrar sesión" class="salir"></a>
        </cosita>
        <cosita class="enviar3">
        <a href="Menu.php">  <input type="button" name="Regresar" value="regresar" class="salir"></a>
        </cosita>
    </form>
</div>


    
    <div id="main-container">

		<table>
			<thead>
				<tr>
                    <th>Clave</th>
					<th>Nombre</th>
                     <th>Fecha_nacimiento</th>
                     <th>Telefono</th>
                     <th>Correo</th>
                     <th>Edad</th>
                     <th>Sexo</th>
                     <th>Dirección</th>
                     <th>Estado</th>
                     <th>Servicio</th>
                     <th>Acudio</th>
                    <th>Eliminar</th>
                    <th>Editar</th>
				</tr>
			</thead>
            <?php while($cliente=mysqli_fetch_array($resultado)) { ?>
			<tr>
                <td><a href="detalle_cliente.php?cve_cliente=<?php echo $cliente['cve_cliente'];?>"><?php echo $cliente['cve_cliente']; ?></a></td>
				<td><?php echo $cliente['nombre']; ?></td>
                <td><?php echo $cliente['fecha_nacimiento']; ?></td>
                <td><?php echo $cliente['telefono']; ?></td>
                <td><?php echo $cliente['correo']; ?></td>
                <td><?php echo $cliente['edad']; ?></td>
                <td><?php echo $cliente['sexo']; ?></td>
                <td><?php echo $cliente['direccion']; ?></td>
                <td><?php echo $cliente['estado']; ?></td>
               <td> <?php echo $cliente['servicio']; ?></td>
               <td><?php echo $cliente['Acudio']; ?></td>
                <td class="eliminar"> <a href="clientes.php?eliminar=<?php echo $cliente['cve_cliente']; ?>">Eliminar</a></td>
                <td class="editar">  <a href="clientes.php?editar=<?php echo $cliente['cve_cliente'];  ?>">Editar</a> </td>
			</tr>

            <?php  } ?>
		</table>
	</div>

</body>
</html>