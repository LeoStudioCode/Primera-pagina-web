<?php
include 'conexion.php';

session_start();//se incia una seción
$_SESSION['correo']=$_POST['correo'];
$_SESSION['password']=$_POST['password'];

$consulta="select * from login where correo ='$_SESSION[correo]' and password ='$_SESSION[password]' ";
$login=mysqli_query($conexion, $consulta);
$filas=mysqli_num_rows($login); //si al ejecutarse la consula encuentra coincidencia devuelve algo

if ($filas>0){
    //guardamos los datos del registro que nos devuelve en un arreglo
    $datos=mysqli_fetch_array($login);
    $_SESSION['nombre']=$datos['nombre'];
    $_SESSION['imagen']=$datos['imagen'];
    header("location:menu_admin.php");
}
else{
    mysqli_close($conexion);
    echo "<script>alert ('Usuario no registrado'); </script>";
    echo "<script>window.location='login.php' </script>";
    session_destroy();
}

mysqli_free_result($login);
//libera los resultados para no consumir memoria
?>