<?php

include 'conexion.php';

$cat_categoria="SELECT * FROM categoria";
$resutado = mysqli_query($conexion, $cat_categoria);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>conocenos</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
    <header>
                <nav>
                    <ul class="menu">
                    <h1 class="icon-restaurant">Restaurante del Tio</h1>
                    <li><a href="../html/index.php" class="icon-menu">Inicio</a></li>
                    <li><a class="icon-restaurant" href="../html/productos.php">Productos</a>
                    <ul class="menu-vertical">
                        <?php while ($categoria=mysqli_fetch_array($resutado)) {?>
                            <li> <a href="prod_general.php?id_categoria=<?php echo $categoria['id_categoria']; ?>"><?php echo $categoria['nombre']; ?></a></li>
                            <?php } ?> 
                    </ul>
                    <li><a href="../html/conocenos.php" class="icon-blogger">Conocenos</a></li>
                    <li><a href="../html/contactanos.php" class="icon-users">Contactanos</a></li>
                    <li><a href="../html/login.php" class="icon-login">Inicie sesion</a></li>
                    </ul>     
                </nav>
    </header>

    <section id="banner">
        <div class="contenedor">
            <img src="../img_prod/Banner2.jpg" alt="banner">
        </div>
    </section>

    <section id="conocenos">
        <div class="contenedor-conoc">
        <h2>Bienvenido a Restuarante del Tio</h2>
            <p>En este Restaurante se vende diferentes tipos de comida
                la cual puedes ver en el apartado incio; Tambien hay
                bebidas y comidas semanales que son hechas por el chef
                Elvis el Restaurante esta ubicado en La Manga Uno 
                Calle Uno #306.
                <br><img src="../img_gen/restaurante.jpg" alt="restaurante">
            </p><br>

            <p>Los alimentos son de gran calidad y se sirven a la mesa.
                El pedido es "a la carta" o se elige de un "menú",
                por lo que los alimentos se cocinan al momento.
                El costo depende del servicio y de la calidad de los
                platos que se consumen. Existen mozos o camareros,
                dirigidos por un Maitre.
            </p>
        </div>
    </section>

    <footer>
        <div class="footer">
        <h4>Restaurante del tio &copy;</h4>
            <div class="redes">
                <a class="icon-twitter-bird" href="#"></a>
                <a class="icon-instagram-filled" href="#"></a>
                <a class="icon-whatsapp" href="#"></a>
                <a class="icon-facebook-rect" href="#"></a>
            </div>
        </div>
    </footer>
</body>
</html>