<?php
session_start();
$varsesion=$_SESSION['correo'];
if($varsesion == null || $varsesion = ""){
    echo 'usted no se ha autentificado';
    die(); //terminar la aplicacion para que no continue ejecutandose
}
?>
<?php
include 'conexion.php';
$id_usuario=$_GET['id_usuario'];

$consulta="select * from login where id_usuario=$id_usuario";
$resultado=mysqli_query($conexion,$consulta);
$admin=mysqli_fetch_assoc($resultado);

//$consulta=mysqli_query($conexion,"select * from tabla");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Detalle Admin</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
    
    <section class="menu_cat">
        <h6>DETALLE: <?php echo $admin['nombre'];?></h6>
        <a href="../html/cat_admin.php"> <button class="active">Regresar</button></a>
    </section>
    <section id="contenedor_detalle">
        <div class="detalle">
        <table class="detalle_tabla">
                    <tr>
                    <td>Nombre: </td>
                    <td><?php echo $admin['nombre'];?></td>
                    </tr>
                    <tr>
                    <td>Correo: </td>
                    
                    <td><?php echo $admin['correo'];?></td>
                    </tr>
                    <tr>
                    <td>Contraseña: </td>
                    
                    <td><?php echo $admin['password'];?></td>
                    </tr>

                    <tr>
                    <td class="imagen_Detalle"><img src="<?php echo $admin['imagen'];?>" /></td>
                    </tr>
                </tr>
                
        </table>   
        </div>
    </section>
</body>
</html>