<?php
session_start();
$varsesion=$_SESSION['correo'];
if($varsesion == null || $varsesion = ""){
    echo 'usted no se ha autentificado';
    die(); //terminar la aplicacion para que no continue ejecutandose
}
?>
<?php
include 'conexion.php';
// CONSULTA A NUESTROS RESGISTROS DADOS DE ALTA
$consulta="select * from usuario";
$resultado=mysqli_query($conexion,$consulta);
$nfilas=mysqli_num_rows($resultado);

//INSERTAR REGISTROS
if(isset($_REQUEST['cve_usuario']) && !isset($_REQUEST['clave'])){
    $cve_usuario=$_REQUEST['cve_usuario'];
    $nombre=$_REQUEST['nombre'];
    $ap_paterno=$_REQUEST['ap_paterno'];
    $ap_materno=$_REQUEST['ap_materno'];
    $imagen=$_REQUEST['imagen'];
    $telefono=$_REQUEST['telefono'];
    $direccion=$_REQUEST['direccion'];

    $subio=false;
    $directorio='../img_usuario';
    $imagen=$directorio."/".$_FILES['imagen']['name'];

    if(is_uploaded_file($_FILES['imagen']['tmp_name'])){
        move_uploaded_file($_FILES['imagen']['tmp_name'],$imagen);
        $subio=true;
        if($subio){
            $insertar="insert into usuario (cve_usuario, nombre, ap_paterno,ap_materno,imagen,telefono,direccion) VALUES('$cve_usuario','$nombre','$ap_paterno','$ap_materno','$imagen','$telefono','$direccion')";
            mysqli_query($conexion,$insertar);
            echo "<script>alert('Empleado registrado');</script>";
            echo"<script>window.location='cat_usuario.php';</script>";
            
        }
    }


else{
    echo"<script>alert('Error');</script>";
}
}
//ELIMINAR REGISTROS
if(isset($_REQUEST['eliminar'])){
    $eliminar=$_REQUEST['eliminar'];
    mysqli_query($conexion,"delete from usuario where cve_usuario=$eliminar");
    echo "<script>alert('Registro borrado');</script>";
    echo"<script>window.location='cat_usuario.php';</script>";
}

//EDITAR REGISTROS
//1.Consulta el registro que va editar
if(isset($_REQUEST['editar'])){
    $editar=$_REQUEST['editar'];
    $registros1=mysqli_query($conexion, "select * from usuario where cve_usuario=$editar");
    $reg=mysqli_fetch_array($registros1);
}
//2.Actualiza el Registro
if(isset($_REQUEST['clave'])){
    $cve_usuario=$_REQUEST['clave'];
    $nombre=$_REQUEST['nombre'];
    $ap_paterno=$_REQUEST['ap_paterno'];
    $ap_materno=$_REQUEST['ap_materno'];
    $imagen=$_REQUEST['imagen'];
    $telefono=$_REQUEST['telefono'];
    $direccion=$_REQUEST['direccion'];

    if(empty($imagen)){
        $imagen1= $_REQUEST['archivo_mod'];

        mysqli_query($conexion, "update usuario set nombre='$nombre', ap_paterno='$ap_paterno', ap_materno='$ap_materno', imagen='$imagen1', telefono='$telefono', direccion='$direccion' where cve_usuario='$cve_usuario'");

    echo "<script>alert('Registro actualizado');</script>";
    echo"<script>window.location='cat_usuario.php';</script>";
    }

    $subio=false;
    $directorio='../img_usuario';
    $imagen=$directorio."/".$_FILES['imagen']['name'];

    if(is_uploaded_file($_FILES['imagen']['tmp_name'])){
        move_uploaded_file($_FILES['imagen']['tmp_name'],$imagen);
        $subio=true;
        if($subio){
            mysqli_query($conexion, "update usuario set nombre='$nombre', ap_paterno='$ap_paterno', ap_materno='$ap_materno', imagen='$imagen', telefono='$telefono', direccion='$direccion' where cve_usuario='$cve_usuario'");

        }
    }


else{
    echo"<script>alert('Error');</script>";
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Catalogo Usuarios</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
        <section class="menu_cat">
            <h6>Administrador: <?php echo $_SESSION['nombre'];?></h6>
            <a href="../html/menu_admin.php"> <button class="active">regresar</button></a>
        </section>
    <section id="contenedor">
        <section id="general">
            
            <form action="cat_usuario.php" method="post" enctype="multipart/form-data">

                <label for="cve_usuario">Clave usuario</label>
                <input type="text" name="cve_usuario" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['cve_usuario']."' disabled"; } ?>placeholder="Clave" size="10" maxlength="8" class="Decorar_cat" readonly><br>
                <label for="nombre">Nombre: </label>
                <input type="text" name="nombre" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['nombre']."' "; } ?>placeholder="Nombre" size="90" class="Decorar_cat"><br>
                <label for="ap_paterno">Apellido Paterno: </label>
                <input type="text" name="ap_paterno" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['ap_paterno']."' "; } ?>placeholder="Apellido Paterno" size="100" class="Decorar_cat"><br>
                <label for="ap_materno">Apellido Materno: </label>
                <input type="text" name="ap_materno" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['ap_materno']."' "; } ?>placeholder="Apellido Materno" size="40" class="Decorar_cat"><br>
                <label for="imagen">Fotografia: </label>
                <input type="file" name="imagen" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['imagen']."' ";  ?>placeholder="Fotografia" class="Decorar_cat"><img src="<?php echo $reg['imagen']; ?>" alt="" width="100" height="100" /> <?php  } ?><br>
                <br><label for="telefono">Telefono: </label>
                <input type="text" name="telefono" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['telefono']."' "; } ?>placeholder="Telefono" size="40" maxlength="10" minlength="10" class="Decorar_cat"><br>
                <label for="direccion">Direccion: </label>
                <input type="text" name="direccion" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['direccion']."' "; } ?>placeholder="Direccion" class="Decorar_cat"><br>
        
                <?php 
                //Creamos un campo oculto archivo_mod
                if(isset($_REQUEST['editar']))
                { echo "<input type='hidden' name='archivo_mod' value='".$reg['imagen']."' >" ;}
                //creamos y pasamos un campo oculto que contiene la clave del empleado
                if(isset($_REQUEST['editar']))
                { echo "<input type='hidden' name='clave' value='".$reg['cve_usuario']."' >" ;}
                ?>

                <!-- Dependiendo si es insertar o editar el boton cambia su etiqueta -->
                <cosita class="button">
                <input type="submit"<?php if(isset($_REQUEST['editar'])){echo "value='Guardar'";} else {echo "value='Insertar'";} ?> id="boton">
                </cosita>
            </form>
        </section><br>
            <h2 class="registrado">Usuarios Registrados</h2><br>
        <div class="catalogos">
            <table class="catt">
            <tr class="tabla-nombre">
                <td>Clave Usuario</td>
                <td>Nombre</td>
                <td>Foto</td>
                <td>Eliminar</td>
                <td>Editar</td>
            </tr>
                <?php while($usuario=mysqli_fetch_array($resultado)) {?>
                <tr class="tabla-info">
                    <td><a href="detalle_usuario.php?cve_usuario=<?php echo $usuario['cve_usuario'];?>"> <?php echo $usuario['cve_usuario']?></a></td>
                    <td><?php echo $usuario['nombre']?></td>
                    <td><img src="<?php echo $usuario['imagen'] ?>" alt=""></td>
                    <td><a class="fas fa-trash-alt fa-2x" href="cat_usuario.php?eliminar=<?php echo $usuario['cve_usuario']; ?>"></a></td>
                    <td><a class="fas fa-edit fa-2x" href="cat_usuario.php?editar=<?php echo $usuario['cve_usuario'];?>"> </a></td>
                </tr>
                <?php }?>
            </table>
        </div>
    </section>
</body>
</html>