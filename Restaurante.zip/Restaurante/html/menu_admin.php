<?php
session_start();
$varsesion=$_SESSION['correo'];
if($varsesion == null || $varsesion = ""){
    echo 'usted no se ha autentificado';
    die(); //terminar la aplicacion para que no continue ejecutandose
}
?>
<!-- 
include 'conexion.php';

$persona= $_SESSION['rol'];

$usuario=mysqli_query($conexion, "SELECT CVE_USUARIO, correo, username, AP_MATERNO, AP_PATERNO, imagen, TELEFONO, ID_ROLES FROM usuario WHERE cve_usuario='$persona'");
$data=mysqli_fetch_array($usuario);


$username=$data['username'];
$imagen=$data['imagen'];



-->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Menu Admin</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
    <section id="admin">
            <div class="perfil">
                <img src="<?php echo $_SESSION['imagen'];?>">
                <h5>Bienvenido: <?php echo $_SESSION['nombre'];?></h5>
                <a href="cerrar.php"> <button class="active">Cerrar Sesion</button></a>
            </div>
            <div class="categorias">
                <a href="../html/cat_admin.php">               
                    
                        <img src="../img_categorias/cat_admin.png" alt="admin"> <h5>Catalogo Administradores</h5></a> 
                    
                <a href="../html/cat_noticia.php">
                    
                        <img src="../img_categorias/cat_not.png" alt="noticias"><h5>Catalogo de Noticias</h5></a>   
                    
                <a href="../html/cat_cat.php">
                    
                        <img src="../img_categorias/cat_cat.png" alt="categorias"><h5>Catalogo de Categorias</h5></a>  
                    
                <a href="../html/cat_prod.php">
                    
                        <img src="../img_categorias/cat_prod.png" alt="productos"><h5>Catalogo de Prodcutos</h5></a>  
                    
                <a href="../html/cat_usuario.php">
                    
                        <img src="../img_categorias/cat_usu.png" alt="usuarios"><h5>Catalogo de Usuarios</h5></a>  
                    
                <a href="../html/comentarios.php">
                    
                    <img src="../img_categorias/mensaje.png" alt="comentarios"><h5>Revision de comentarios</h5></a>
                    
            </div>
    </section>
</body>
</html>