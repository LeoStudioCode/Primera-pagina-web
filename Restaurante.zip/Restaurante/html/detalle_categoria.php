<?php
session_start();
$varsesion=$_SESSION['correo'];
if($varsesion == null || $varsesion = ""){
    echo 'usted no se ha autentificado';
    die(); //terminar la aplicacion para que no continue ejecutandose
}
?>
<?php
include 'conexion.php';
$id_categoria=$_GET['id_categoria'];

$consulta="select * from categoria where id_categoria=$id_categoria";
$resultado=mysqli_query($conexion,$consulta);
$categorias=mysqli_fetch_assoc($resultado);

//$consulta=mysqli_query($conexion,"select * from tabla");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Detalle empleado</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
    
    <section class="menu_cat">
        <h6>DETALLE: <?php echo $categorias['nombre'];?></h6>
        <a href="../html/cat_cat.php"> <button class="active">regresar</button></a>
    </section>
    <section id="contenedor_detalle">
        <div class="detalle">
        <table class="detalle_tabla">
            <tr>
                <td>ID: </td>
                <td><?php echo $categorias['id_categoria'];?></td>
            </tr>
                <tr>
                    <td>Nombre de la categoria: </td>
                    <td><?php echo $categorias['nombre'];?></td>
                </tr>
                <tr>
                    <td class="imagen_Detalle"><img src="<?php echo $categorias['imagen'];?>"/></td>
                </tr>
                
        </table>
        </div>   
    </section>
</body>
</html>