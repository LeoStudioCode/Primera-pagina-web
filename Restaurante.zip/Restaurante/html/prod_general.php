<!--$nombre=$_GET['nombre']
$n_categoria=mysqli_query($conexion,"select * from productos where ")-->
<?php

include 'conexion.php';

$cat_categoria="SELECT * FROM categoria";
$resultado = mysqli_query($conexion, $cat_categoria);
$id_categoria=$_GET['id_categoria'];
$c_producto=mysqli_query($conexion,"select * from productos where id_categoria=$id_categoria");


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proyecto</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
    <header>
                <nav>
                    <ul class="menu">
                    <h1 class="icon-restaurant">Restaurante del Tio</h1>
                    <li><a href="../html/index.php" class="icon-menu">Inicio</a></li>
                    <li><a class="icon-restaurant" href="../html/productos.php">Productos</a>
                    <ul class="menu-vertical">
                        <?php while ($categoria=mysqli_fetch_array($resultado)) {?>
                            <li> <a href="prod_general.php?id_categoria=<?php echo $categoria['id_categoria']; ?>"><?php echo $categoria['nombre']; ?></a></li>
                            <?php } ?> 
                    </ul>
                    <li><a href="../html/conocenos.php" class="icon-blogger">Conocenos</a></li>
                    <li><a href="../html/contactanos.php" class="icon-users">Contactanos</a></li>
                    <li><a href="../html/login.php" class="icon-login">Inicie sesion</a></li>
                    </ul>     
                </nav>
    </header>

    <section id="banner">
        <div class="contenedor">
            <img src="../img_prod/Banner2.jpg" alt="banner">
        </div>
    </section>

    <section id="productos">
        
        <div class="contenedor">
        <?php 
            $cat_categoria1="SELECT * FROM categoria";
            $resultado19 = mysqli_query($conexion, $cat_categoria1);
            $prod=mysqli_query($conexion,"select * from categoria where id_categoria=$id_categoria"); 
            $resultado20=mysqli_fetch_array($prod)
        ?>
            <h2><?php echo $resultado20 ["nombre"];  ?></h2>
            
            <?php while($resultado2=mysqli_fetch_array($c_producto)) {?>
                
            <article>
                <a href="detalle_prod_general.php?cve_producto=<?php echo $resultado2['cve_producto'];?>"><img src="<?php echo $resultado2['imagen']; ?>" alt="<?php echo $resultado2['imagen']; ?>"></a><br>
                <h7><?php echo $resultado2['nombre'];?></h7>
                <h7>$<?php echo $resultado2['precio']; ?></h7>
            </article>
            
            <?php }?>
            
        </div>
    </section>

    <footer>
            <div class="footer">
            <h4>Restaurante del tio &copy;</h4>
                <div class="redes">
                    <a class="icon-twitter-bird" href="#"></a>
                    <a class="icon-instagram-filled" href="#"></a>
                    <a class="icon-whatsapp" href="https://wa.me/qr/7KBOPQIVIZOOP1"></a>
                    <a class="icon-facebook-rect" href="#"></a>
                </div>
            </div>
    </footer>
</body>
</html>