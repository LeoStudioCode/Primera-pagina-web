<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proyecto</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
    <header>
                <nav>
                    <ul class="menu">
                    <h1 class="icon-restaurant">Restaurante del Tio</h1>
                    <li><a href="../html/index.php" class="icon-menu">Inicio</a></li>
                    <li><a href="../html/productos.php">Productos</a>
                        <ul>
                            <li><a href="../html/tacos.php">Tacos</a></li>
                            <li><a href="../html/pasteles.php">Pasteles</a></li>
                            <li><a href="../html/bebidas.php">Bebidas</a>
                        </ul>
                    <li><a href="../html/conocenos.php" class="icon-blogger">Conocenos</a></li>
                    <li><a href="../html/contactanos.php" class="icon-users">Contactanos</a></li>
                    <li><a href="../html/login.php" class="icon-login">Inicie sesion</a></li>
                    </ul>     
                </nav>
    </header>

    <section id="banner">
        <div class="contenedor">
            <img src="../img_prod/Banner2.jpg" alt="banner">
        </div>
    </section>

    <section id="productos">
        
        <div class="contenedor">
            <h2>PASTELES</h2>
            <article>
                <img src="../img_prod/Platillo.jpg" alt="producto1">
                <h3>Platillo completo $300.00</h3>
                <h3>Especificaciones</h3>
            </article>
            <article>
                <img src="../img_prod/Tacos.jfif" alt="producto2">
                <h3>Tacos $20.00</h3>
            </article>
            <article>
                <img src="../img_prod/Espagueti.jpg" alt="producto3">
                <h3>Espagueti $120.00</h3>
            </article>
            <article>
                <img src="../img_prod/Donas.jfif" alt="producto4">
                <h3>Donas $15.00</h3>
            </article>
            <h2>BEBIDAS</h2>
            <article>
                <img src="../img_prod/malteadas.webp" alt="malteadas">
                <h3>Maltedas $80.00</h3>
            </article>
            <article>
                <img src="../img_prod/aguas.webp" alt="aguas">
                <h3>Aguas Naturales $40</h3>
            </article>
        </div>
    </section>

    <footer>
            <div class="footer">
            <h4>Restaurante del tio &copy;</h4>
                <div class="redes">
                    <a class="icon-twitter-bird" href="#"></a>
                    <a class="icon-instagram-filled" href="#"></a>
                    <a class="icon-whatsapp" href="https://wa.me/qr/7KBOPQIVIZOOP1"></a>
                    <a class="icon-facebook-rect" href="#"></a>
                </div>
            </div>
    </footer>
</body>
</html>