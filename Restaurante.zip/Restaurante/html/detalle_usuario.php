<?php
session_start();
$varsesion=$_SESSION['correo'];
if($varsesion == null || $varsesion = ""){
    echo 'usted no se ha autentificado';
    die(); //terminar la aplicacion para que no continue ejecutandose
}
?>
<?php
include 'conexion.php';
$cve_usuario=$_GET['cve_usuario'];

$consulta="select * from usuario where cve_usuario=$cve_usuario";
$resultado=mysqli_query($conexion,$consulta);
$usuarios=mysqli_fetch_assoc($resultado);

//$consulta=mysqli_query($conexion,"select * from tabla");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Detalle empleado</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
    
    <section class="menu_cat">
        <h6>DETALLE: <?php echo $usuarios['nombre'];?></h6>
        <a href="../html/cat_usuario.php"> <button class="active">regresar</button></a>
    </section>
    <section id="contenedor_detalle">
        <div class="detalle">
        <table class="detalle_tabla">
                    <tr>
                    <td>Nombre: </td>
                    <td><?php echo $usuarios['nombre'];?></td>
                    </tr>
                    <tr>
                    <td>Apellido Paterno: </td>
                    
                    <td><?php echo $usuarios['ap_paterno'];?></td>
                    </tr>
                    <tr>
                    <td>Apellido Materno: </td>
                    
                    <td><?php echo $usuarios['ap_materno'];?></td>
                    </tr>
                    <tr>
                    <td>Telefono: </td>
                    
                    <td><?php echo $usuarios['telefono'];?></td>
                    </tr>
                    <tr>
                    <td>Direccion: </td>
                    <td><?php echo $usuarios['direccion'];?></td>
                    </tr>  
                    <tr>
                    <td class="imagen_Detalle"><img src="<?php echo $usuarios['imagen'];?>" /></td>
                    </tr>
                </tr>
                
        </table>   
        </div>
    </section>
</body>
</html>