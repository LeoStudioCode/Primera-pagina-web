<?php
session_start();
$varsesion=$_SESSION['correo'];
if($varsesion == null || $varsesion = ""){
    echo 'usted no se ha autentificado';
    die(); //terminar la aplicacion para que no continue ejecutandose
}
?>
<?php
include 'conexion.php';
// CONSULTA A NUESTROS RESGISTROS DADOS DE ALTA
$consulta="select * from productos";
$resultado=mysqli_query($conexion,$consulta);
$nfilas=mysqli_num_rows($resultado);

//INSERTAR REGISTROS
if(isset($_REQUEST['cve_producto']) && !isset($_REQUEST['clave'])){
    $cve_producto=$_REQUEST['cve_producto'];
    $imagen=$_REQUEST['imagen'];
    $nombre=$_REQUEST['nombre'];
    $descripcion=$_REQUEST['descripcion'];
    $precio=$_REQUEST['precio'];
    $id_categoria=$_REQUEST['id_categoria'];

    $subio=false;
    $directorio='../img_prod';
    $imagen=$directorio."/".$_FILES['imagen']['name'];

    if(is_uploaded_file($_FILES['imagen']['tmp_name'])){
        move_uploaded_file($_FILES['imagen']['tmp_name'],$imagen);
        $subio=true;
        if($subio){
            $insertar="insert into productos (cve_producto, imagen, nombre, descripcion, precio, id_categoria) VALUES('$cve_producto','$imagen','$nombre','$descripcion','$precio','$id_categoria')";
            mysqli_query($conexion,$insertar);
            echo "<script>alert('Producto registrado');</script>";
            echo"<script>window.location='cat_prod.php';</script>";
            
        }
    }


else{
    echo"<script>alert('Error');</script>";
}
}
//ELIMINAR REGISTROS
if(isset($_REQUEST['eliminar'])){
    $eliminar=$_REQUEST['eliminar'];
    mysqli_query($conexion,"delete from productos where cve_producto=$eliminar");
    echo "<script>alert('Producto borrado');</script>";
    echo"<script>window.location='cat_prod.php';</script>";
}

//EDITAR REGISTROS
//1.Consulta el registro que va editar
if(isset($_REQUEST['editar'])){
    $editar=$_REQUEST['editar'];
    $registros1=mysqli_query($conexion, "select * from productos where cve_producto=$editar");
    $reg=mysqli_fetch_array($registros1);
}
//2.Actualiza el Registro
if(isset($_REQUEST['clave'])){
    $cve_producto=$_REQUEST['clave'];
    $imagen=$_REQUEST['imagen'];
    $nombre=$_REQUEST['nombre'];
    $descripcion=$_REQUEST['descripcion'];
    $precio=$_REQUEST['precio'];
    $id_categoria=$_REQUEST['id_categoria'];

    if(empty($imagen)){
        $imagen1= $_REQUEST['archivo_mod'];

        mysqli_query($conexion, "update productos set imagen='$imagen1', nombre='$nombre', descripcion='$descripcion', precio='$precio' where cve_producto='$cve_producto'");
        echo "<script>alert('Producto Actualizado');</script>";
        echo"<script>window.location='cat_prod.php';</script>";

    }

    $subio=false;
    $directorio='../img_prod';
    $imagen=$directorio."/".$_FILES['imagen']['name'];

    if(is_uploaded_file($_FILES['imagen']['tmp_name'])){
        move_uploaded_file($_FILES['imagen']['tmp_name'],$imagen);
        $subio=true;
        if($subio){
            mysqli_query($conexion, "update productos set imagen='$imagen', nombre='$nombre', descripcion='$descripcion', precio='$precio', id_categoria='$id_categoria' where cve_producto='$cve_producto'");

        }
    }


else{
    echo"<script>alert('Error');</script>";
}
}
$consulta2= "SELECT*FROM categoria";

//especificar error en mysqli_error
$ejecutar=mysqli_query($conexion,$consulta2) or die (mysqli_error($conexion));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Catalogo Usuarios</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
        <section class="menu_cat">
            <h6>Administrador: <?php echo $_SESSION['nombre'];?></h6>
            <a href="../html/menu_admin.php"> <button class="active">regresar</button></a>
        </section>
    <section id="contenedor">
        <section id="general">
            
            <form action="cat_prod.php" method="post" enctype="multipart/form-data">

                <label for="cve_producto">Clave Productos</label>
                <input type="text" name="cve_producto" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['cve_producto']."'disabled "; } ?>placeholder="Clave" size="10" maxlength="8"  class="Decorar_cat" readonly><br>
                <label for="nombre">Nombre: </label>
                <input type="text" name="nombre" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['nombre']."' "; } ?>placeholder="Nombre" size="90" class="Decorar_cat"><br>
                <label for="imagen">Fotografia: </label>
                <input type="file" name="imagen" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['imagen']."' ";  ?>placeholder="Fotografia" size="40" class="Decorar_cat"><img src="<?php echo $reg['imagen']; ?>" alt="" width="100" height="100" /> <?php  } ?><br>
                <br><label for="descripcion">Descripcion </label>
                <input type="text" name="descripcion" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['descripcion']."' "; } ?>placeholder="Descripcion" size="40" class="Decorar_cat"><br>
                <label for="precio">Precio: </label>
                <input type="text" name="precio" <?php if(isset($_REQUEST['editar'])) {echo "value='".$reg['precio']."' "; } ?>placeholder="Precio" size="40" class="Decorar_cat"><br>
                Categoria: 
                <select name="id_categoria" id="id_categoria" class="Decorar_cat">
                    <?php foreach ($ejecutar as $key => $opciones): ?>

                        <option value="<?php echo $opciones ['id_categoria'] ?>"><?php echo $opciones ['nombre'] ?></option>

                     <?php endforeach ?>
                </select><br>

                <!--
                <input type="text" name="id_categoria" <php if(isset($_REQUEST['editar'])) {echo "value='".$reg['id_categoria']."' "; } ?>placeholder="Categoria" class="Decorar_cat"><br>
-->
                <?php 
                //Creamos un campo oculto archivo_mod
                if(isset($_REQUEST['editar']))
                { echo "<input type='hidden' name='archivo_mod' value='".$reg['imagen']."' >" ;}

                //creamos y pasamos un campo oculto que contiene la clave del empleado
                if(isset($_REQUEST['editar']))
                { echo "<input type='hidden' name='clave' value='".$reg['cve_producto']."' >" ;}
                
                //Creamos un campo oculto depto_mod
                if(isset($_REQUEST['editar']))
                { echo "<input type='hidden' name='cat_mod' value='".$reg['id_categoria']."' >" ;}
                ?>

                <!-- Dependiendo si es insertar o editar el boton cambia su etiqueta -->
                <cosita class="button">
                <input type="submit" <?php if(isset($_REQUEST['editar'])){echo "value='Guardar'";} else {echo "value='insertar'";} ?> id="boton">
                </cosita>
            </form>
        </section><br>
            <h2 class="registrado">Productos Registrados</h2><br>
        <div class="catalogos">
            <table class="catt">
            <tr class="tabla-nombre">
                <td>Clave Productos</td>
                <td>Categoria</td>
                <td>Nombre</td>
                <td>Imagen</td>
                <td>Eliminar</td>
                <td>Editar</td>
            </tr>
                <?php while($producto=mysqli_fetch_array($resultado)) {?>
                <tr class="tabla-info">
                    <td><a href="detalle_productos.php?cve_producto=<?php echo $producto['cve_producto'];?>"> <?php echo $producto['cve_producto']?></a></td>
                    <td><?php echo $producto['id_categoria']?></td>
                    <td><?php echo $producto['nombre']?></td>
                    <td><img src="<?php echo $producto['imagen'] ?>" alt=""></td>
                    <td><a class="fas fa-trash-alt fa-2x" href="cat_prod.php?eliminar=<?php echo $producto['cve_producto']; ?>"></a></td>
                    <td><a class="fas fa-edit fa-2x" href="cat_prod.php?editar=<?php echo $producto['cve_producto'];?>"></a></td>
                </tr>
                <?php }?>
            </table>
        </div>
        </section>

</body>
</html>