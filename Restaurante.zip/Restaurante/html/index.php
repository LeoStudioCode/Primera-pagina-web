<?php

include 'conexion.php';

$cat_categoria="SELECT * FROM categoria";
$resultado = mysqli_query($conexion, $cat_categoria);

$noticia=mysqli_query($conexion, "select * from noticia order by fecha desc limit 3");
$resultado_not=mysqli_fetch_array($noticia);

?>

<?php
$consulta_cat="select * from categoria";
$categorias=mysqli_query($conexion,$consulta_cat);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proyecto</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
    <header>
            <nav>
                <ul class="menu">
                <h1 class="icon-restaurant">Restaurante del Tio</h1>
                <li><a href="../html/index.php" class="icon-menu">Inicio</a></li>
                <li><a class="icon-restaurant" href="../html/productos.php">Productos</a>
                    <ul class="menu-vertical">
                        <?php while ($categoria=mysqli_fetch_array($resultado)) {?>
                            <li> <a href="prod_general.php?id_categoria=<?php echo $categoria['id_categoria']; ?>"><?php echo $categoria['nombre']; ?></a></li>
                            <?php } ?> 
                    </ul>
                <li><a href="../html/conocenos.php" class="icon-blogger">Conocenos</a></li>
                <li><a href="../html/contactanos.php" class="icon-users">Contactanos</a></li>
                <li><a href="../html/login.php" class="icon-login">Inicie sesion</a></li>
                </ul>     
            </nav>
    </header>

    <section id="banner">
        <div class="contenedor">
            <img src="../img_prod/Banner2.jpg" alt="banner">
        </div>
    </section>

    <section id="productos">
        
        <div class="contenedor">
            <h2>PRODUCTOS DEL RESTAURANTE</h2>
            <?php while($cat1=mysqli_fetch_array($categorias)){ ?>
     
            <article>
                <a href="prod_general.php?id_categoria=<?php echo $cat1['id_categoria']; ?>"><img src="<?php echo $cat1['imagen']; ?>" /></a><br>
                <?php echo $cat1['nombre']; ?><br>
            </article>
     <?php } ?>
            <table id="noticia">
                <tr class="box_noticia_nombre">
                    <td>Fecha de la noticia</td>
                    <td>Tiulo</td>
                    <td>Noticia</td>
                </tr>
                <?php do{?>
                    <tr class="box_noticia">
                        <td><?php echo $resultado_not['fecha']?></td>
                        <td><?php echo $resultado_not['titulo']?></td>
                        <td><?php echo $resultado_not['contenido']?></td>
                    </tr>
                <?php } while ($resultado_not=mysqli_fetch_array($noticia));?>
            </table>
        </div>
    </section>

    <footer>
            <div class="footer">
            <h4>Restaurante del tio &copy;</h4>
                <div class="redes">
                    <a class="icon-twitter-bird" href="#"></a>
                    <a class="icon-instagram-filled" href="#"></a>
                    <a class="icon-whatsapp" href="https://wa.me/qr/7KBOPQIVIZOOP1"></a>
                    <a class="icon-facebook-rect" href="#"></a>
                </div>
            </div>
    </footer>
</body>
<!--          
<li><a href="../html/tacos.php">Tacos</a></li>
<li><a href="../html/Postres.php">Postres</a></li>
<li><a href="../html/bebidas.php">Bebidas</a>
-->       
</html>