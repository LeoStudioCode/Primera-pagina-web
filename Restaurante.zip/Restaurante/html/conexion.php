<?php

$conexion  = mysqli_connect("localhost", "root", "", "restaurante");


/*if($conexion){
    echo 'conectado exitosamente';
}else{
    echo 'no ha podido conectar';
}
*/
?>

